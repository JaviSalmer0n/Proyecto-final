<?php
// Correos que tendrán rol administrador al iniciar sesión (DEMO).
$ADMIN_EMAILS = [
    'admin@municipio.local',
    'administrador@demo.local'
];

// Lista de empresas disponibles para asignar reportes (DEMO).
$EMPRESAS = [
    'TecSoluciones S.A.',
    'InfraRed Consultores',
    'Ciudad Limpia SRL',
    'Seguridad Plus',
    'Agua Clara Servicios'
];