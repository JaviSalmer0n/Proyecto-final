<?php
require_once __DIR__ . '/includes/helpers.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }

$ok = false;
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $correo = trim($_POST['correo'] ?? '');
    $pass   = trim($_POST['pass'] ?? '');
    if ($nombre === '' || $correo === '' || $pass === '') {
        $err = 'Todos los campos son obligatorios.';
    } else {
        // DEMO: no hay persistencia; en tu implementación real, guarda en DB con password_hash().
        $ok = true;
    }
}

include __DIR__ . '/includes/header.php';
?>
<section class="container">
    <h2>Registro</h2>
    <?php if ($err): ?>
        <p class="badge" style="display:block;margin:.75rem 0;"><?php echo h($err); ?></p>
    <?php endif; ?>

    <?php if ($ok): ?>
        <div class="card mt">
            <p>Registro simulado correctamente. Ahora puedes <a href="login.php">iniciar sesión</a>.</p>
        </div>
    <?php else: ?>
        <form method="post" class="mt">
            <div class="form-group">
                <label for="nombre">Nombre completo</label>
                <input id="nombre" name="nombre" type="text" required />
            </div>
            <div class="form-group">
                <label for="correo">Correo</label>
                <input id="correo" name="correo" type="email" required />
            </div>
            <div class="form-group">
                <label for="pass">Contraseña</label>
                <input id="pass" name="pass" type="password" required />
            </div>
            <button class="btn">Crear Cuenta</button>
        </form>
    <?php endif; ?>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>