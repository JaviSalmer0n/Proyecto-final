<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/helpers.php';
$rol = $_SESSION['user_role'] ?? null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Municipio Conectado</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="includes/Estilos.css">
</head>
<body>
<header class="main-header">
    <div class="logo"><span class="brand">Municipio Conectado</span></div>
    <nav class="main-nav">
        <ul>
            <li><a href="index.php">Inicio</a></li>
            <li><a href="reporte_nuevo.php">Nuevo Reporte</a></li>
            <li><a href="estadisticas.php">Estadísticas</a></li>
            <?php if ($rol): ?>
                <li><a href="<?= enlace_panel_por_rol($rol); ?>">Panel</a></li>
                <li><a href="logout.php" class="btn btn-outlined">Cerrar Sesión</a></li>
            <?php else: ?>
                <li><a href="login.php" class="btn">Ingresar</a></li>
                <li><a href="registro.php" class="btn btn-secondary">Registrarse</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>
<main>