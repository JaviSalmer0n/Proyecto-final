</main>
<footer class="main-footer">
    <div class="footer-content">
        <p>&copy; <?= date('Y'); ?> Municipio Conectado. Todos los derechos reservados.</p>
        <p class="mini">Proyecto académico - Simulación.</p>
    </div>
</footer>
</body>
</html>