<!doctype html>
<html lang="es">
    <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width,initial-scale=1">
     <title><?php echo isset($page_title) && $page_title ? $page_title : $app['title_default']; ?></title>
      <link rel="stylesheet" href="css/estilos.css">
    </head>

