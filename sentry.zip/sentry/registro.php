<?php 
    include "header.php"
?>
<body>

<?php 

    include "footer.php"
?>

